package sudoku

import (
	"bytes"
	"context"
	"io"
	"net"
	"sync/atomic"
	"testing"
	"time"

	"github.com/metacubex/mihomo/transport/sudoku/multiplex"
	sudokuobfs "github.com/metacubex/mihomo/transport/sudoku/obfs/sudoku"
)

func TestUserHash_StableAcrossTableRotation(t *testing.T) {
	tables := []*sudokuobfs.Table{
		sudokuobfs.NewTable("seed-a", "prefer_ascii"),
		sudokuobfs.NewTable("seed-b", "prefer_ascii"),
	}
	key := "userhash-stability-key"

	serverCfg := DefaultConfig()
	serverCfg.Key = key
	serverCfg.AEADMethod = "chacha20-poly1305"
	serverCfg.Tables = tables
	serverCfg.PaddingMin = 0
	serverCfg.PaddingMax = 0
	serverCfg.EnablePureDownlink = true
	serverCfg.HandshakeTimeoutSeconds = 5
	serverCfg.DisableHTTPMask = true

	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatalf("listen: %v", err)
	}
	t.Cleanup(func() { _ = ln.Close() })

	const attempts = 32
	hashCh := make(chan string, attempts)
	errCh := make(chan error, attempts)

	go func() {
		for {
			c, err := ln.Accept()
			if err != nil {
				return
			}
			go func(conn net.Conn) {
				defer conn.Close()
				_, meta, err := ServerHandshake(conn, serverCfg)
				if err != nil {
					errCh <- err
					return
				}
				if meta == nil || meta.UserHash == "" {
					errCh <- io.ErrUnexpectedEOF
					return
				}
				hashCh <- meta.UserHash
			}(c)
		}
	}()

	clientCfg := DefaultConfig()
	*clientCfg = *serverCfg
	clientCfg.ServerAddress = ln.Addr().String()

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	for i := 0; i < attempts; i++ {
		raw, err := (&net.Dialer{}).DialContext(ctx, "tcp", clientCfg.ServerAddress)
		if err != nil {
			t.Fatalf("dial %d: %v", i, err)
		}
		cConn, err := ClientHandshake(raw, clientCfg)
		if err != nil {
			_ = raw.Close()
			t.Fatalf("handshake %d: %v", i, err)
		}

		_ = cConn.Close()
	}

	unique := map[string]struct{}{}
	deadline := time.After(10 * time.Second)
	for i := 0; i < attempts; i++ {
		select {
		case err := <-errCh:
			t.Fatalf("server handshake error: %v", err)
		case h := <-hashCh:
			if h == "" {
				t.Fatalf("empty user hash")
			}
			if len(h) != 16 {
				t.Fatalf("unexpected user hash length: %d", len(h))
			}
			unique[h] = struct{}{}
		case <-deadline:
			t.Fatalf("timeout waiting for server handshakes")
		}
	}
	if len(unique) != 1 {
		t.Fatalf("user hash should be stable across table rotation; got %d distinct values", len(unique))
	}
}

func TestMultiplex_TCP_Echo(t *testing.T) {
	table := sudokuobfs.NewTable("seed", "prefer_ascii")
	key := "test-key-mux"
	target := "example.com:80"

	serverCfg := DefaultConfig()
	serverCfg.Key = key
	serverCfg.AEADMethod = "chacha20-poly1305"
	serverCfg.Table = table
	serverCfg.PaddingMin = 0
	serverCfg.PaddingMax = 0
	serverCfg.EnablePureDownlink = true
	serverCfg.HandshakeTimeoutSeconds = 5
	serverCfg.DisableHTTPMask = true

	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatalf("listen: %v", err)
	}
	t.Cleanup(func() { _ = ln.Close() })

	var handshakes int64
	var streams int64
	done := make(chan struct{})

	go func() {
		defer close(done)
		raw, err := ln.Accept()
		if err != nil {
			return
		}
		defer raw.Close()

		c, meta, err := ServerHandshake(raw, serverCfg)
		if err != nil {
			return
		}
		atomic.AddInt64(&handshakes, 1)

		session, err := ReadServerSession(c, meta)
		if err != nil {
			return
		}
		if session.Type != SessionTypeMultiplex {
			_ = c.Close()
			return
		}

		mux, err := AcceptMultiplexServer(c)
		if err != nil {
			return
		}
		defer mux.Close()

		for {
			stream, dst, err := mux.AcceptTCP()
			if err != nil {
				return
			}
			if dst != target {
				_ = stream.Close()
				return
			}
			atomic.AddInt64(&streams, 1)
			go func(c net.Conn) {
				defer c.Close()
				_, _ = io.Copy(c, c)
			}(stream)
		}
	}()

	clientCfg := DefaultConfig()
	*clientCfg = *serverCfg
	clientCfg.ServerAddress = ln.Addr().String()

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	raw, err := (&net.Dialer{}).DialContext(ctx, "tcp", clientCfg.ServerAddress)
	if err != nil {
		t.Fatalf("dial: %v", err)
	}
	t.Cleanup(func() { _ = raw.Close() })

	cConn, err := ClientHandshake(raw, clientCfg)
	if err != nil {
		t.Fatalf("client handshake: %v", err)
	}

	mux, err := StartMultiplexClient(context.Background(), cConn)
	if err != nil {
		_ = cConn.Close()
		t.Fatalf("start mux: %v", err)
	}
	defer mux.Close()

	for i := 0; i < 6; i++ {
		s, err := mux.Dial(ctx, target)
		if err != nil {
			t.Fatalf("dial stream %d: %v", i, err)
		}

		msg := []byte("hello-mux")
		if _, err := s.Write(msg); err != nil {
			_ = s.Close()
			t.Fatalf("write: %v", err)
		}
		buf := make([]byte, len(msg))
		if _, err := io.ReadFull(s, buf); err != nil {
			_ = s.Close()
			t.Fatalf("read: %v", err)
		}
		_ = s.Close()
		if !bytes.Equal(buf, msg) {
			t.Fatalf("echo mismatch: got %q", buf)
		}
	}

	_ = mux.Close()
	select {
	case <-done:
	case <-time.After(5 * time.Second):
		t.Fatalf("server did not exit")
	}

	if got := atomic.LoadInt64(&handshakes); got != 1 {
		t.Fatalf("unexpected handshake count: %d", got)
	}
	if got := atomic.LoadInt64(&streams); got < 6 {
		t.Fatalf("unexpected stream count: %d", got)
	}
}

func TestMultiplexDialerMaintainReconnectsClosedSession(t *testing.T) {
	var calls atomic.Int32
	peers := make(chan net.Conn, 2)
	dialer, err := NewMultiplexDialer(func(context.Context) (net.Conn, error) {
		calls.Add(1)
		clientConn, serverConn := net.Pipe()
		peers <- serverConn
		return clientConn, nil
	})
	if err != nil {
		t.Fatalf("new dialer: %v", err)
	}

	ctx, cancel := context.WithCancel(context.Background())
	done := make(chan struct{})
	go func() {
		defer close(done)
		dialer.Maintain(ctx)
	}()
	t.Cleanup(func() {
		cancel()
		_ = dialer.Close()
		<-done
	})

	firstServer := startTestMultiplexPeer(t, <-peers)
	_ = firstServer.Close()

	select {
	case peer := <-peers:
		server := startTestMultiplexPeer(t, peer)
		t.Cleanup(func() { _ = server.Close() })
	case <-time.After(2 * time.Second):
		t.Fatalf("maintainer did not reconnect; base dial count=%d", calls.Load())
	}
}

func TestMultiplexDialerCloseCancelsCreation(t *testing.T) {
	started := make(chan struct{})
	canceled := make(chan struct{})
	dialer, err := NewMultiplexDialer(func(ctx context.Context) (net.Conn, error) {
		close(started)
		<-ctx.Done()
		close(canceled)
		return nil, ctx.Err()
	})
	if err != nil {
		t.Fatalf("new dialer: %v", err)
	}

	done := make(chan struct{})
	go func() {
		defer close(done)
		dialer.Maintain(context.Background())
	}()
	<-started
	if err := dialer.Close(); err != nil {
		t.Fatalf("close: %v", err)
	}
	select {
	case <-canceled:
	case <-time.After(time.Second):
		t.Fatal("base dial was not canceled")
	}
	select {
	case <-done:
	case <-time.After(time.Second):
		t.Fatal("maintainer did not stop")
	}
}

func startTestMultiplexPeer(t *testing.T, conn net.Conn) *multiplex.Session {
	t.Helper()
	msg, err := ReadKIPMessage(conn)
	if err != nil {
		t.Fatalf("read mux start: %v", err)
	}
	if msg.Type != KIPTypeStartMux || len(msg.Payload) != 0 {
		t.Fatalf("unexpected mux start: type=%d payload=%d", msg.Type, len(msg.Payload))
	}
	session, err := multiplex.NewServerSession(conn)
	if err != nil {
		t.Fatalf("new server session: %v", err)
	}
	return session
}
